# Guide de déploiement HabitOS
## 30 minutes — tout clic par clic, aucune ligne de commande

---

## ÉTAPE 1 — Créer ta base de données (Supabase)

1. Va sur **https://supabase.com** et clique **Start your project**
2. Connecte-toi avec ton compte GitHub
3. Clique **New project**
4. Remplis :
   - **Name** : habitOS
   - **Database Password** : choisis un mot de passe fort (note-le quelque part)
   - **Region** : choisis la plus proche (ex: West EU)
5. Clique **Create new project** — attends 1-2 minutes

6. Une fois créé, va dans **Project Settings** (icône engrenage en bas à gauche)
7. Clique **API**
8. Note ces deux valeurs (tu en auras besoin à l'étape 3) :
   - **Project URL** → ressemble à `https://xxxxx.supabase.co`
   - **anon public key** → longue chaîne de lettres

9. Maintenant va dans **SQL Editor** (icône dans le menu gauche)
10. Clique **New query**
11. Copie-colle ce code SQL et clique **Run** :

```sql
create table user_data (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users not null unique,
  data jsonb default '{}'::jsonb,
  updated_at timestamp with time zone default now()
);

alter table user_data enable row level security;

create policy "Users can only access their own data"
  on user_data for all
  using (auth.uid() = user_id);
```

Tu devrais voir **Success** en vert. Ta base de données est prête.

---

## ÉTAPE 2 — Mettre le code sur GitHub

1. Va sur **https://github.com** et connecte-toi
2. Clique le **+** en haut à droite → **New repository**
3. Remplis :
   - **Repository name** : habitOS
   - Laisse tout le reste par défaut
4. Clique **Create repository**

5. Sur la page qui s'ouvre, clique **uploading an existing file**
6. Glisse-dépose le fichier **index.html** dans la zone
7. Clique **Commit changes**

---

## ÉTAPE 3 — Ajouter tes clés Supabase dans le fichier

Avant de déployer, tu dois mettre tes clés dans le code :

1. Sur GitHub, clique sur **index.html** pour l'ouvrir
2. Clique le **crayon** (Edit) en haut à droite
3. Trouve ces deux lignes (vers le début du fichier) :
   ```
   const SUPABASE_URL = 'REMPLACE_PAR_TON_URL';
   const SUPABASE_KEY = 'REMPLACE_PAR_TA_CLE';
   ```
4. Remplace `REMPLACE_PAR_TON_URL` par ton **Project URL** de Supabase
5. Remplace `REMPLACE_PAR_TA_CLE` par ta **anon public key** de Supabase
6. Clique **Commit changes**

---

## ÉTAPE 4 — Déployer en ligne (Vercel)

1. Va sur **https://vercel.com** et clique **Sign Up**
2. Choisis **Continue with GitHub**
3. Autorise Vercel à accéder à ton GitHub
4. Clique **Add New** → **Project**
5. Tu vois ton repo **habitOS** — clique **Import**
6. Laisse tout par défaut et clique **Deploy**
7. Attends 1 minute...

**C'est en ligne !** Vercel te donne une URL du type :
`https://habit-os-ton-nom.vercel.app`

---

## ÉTAPE 5 — Utiliser l'appli

1. Ouvre l'URL sur ton PC et sur ton téléphone
2. Crée un compte avec ton email
3. Toutes tes données se synchronisent automatiquement entre les appareils

### Sur téléphone — ajouter en favori sur l'écran d'accueil :
- **iPhone** : Safari → icône partager → "Sur l'écran d'accueil"
- **Android** : Chrome → menu (3 points) → "Ajouter à l'écran d'accueil"

L'appli se comporte comme une vraie application installée.

---

## En cas de problème

- **Erreur "Invalid API key"** → vérifie que tu as bien copié les clés Supabase sans espace
- **Page blanche** → attends 2 minutes et recharge
- **"User not found"** → crée un nouveau compte depuis l'appli

---

## Pour mettre à jour l'appli plus tard

Si tu veux modifier quelque chose :
1. Va sur GitHub → ton repo habitOS → index.html → Edit
2. Fais tes modifications
3. Commit changes
4. Vercel redéploie automatiquement en 1 minute
